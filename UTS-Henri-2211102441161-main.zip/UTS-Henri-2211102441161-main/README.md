# Greenfoot-snake

Snake game build with [Greenfoot](http://www.greenfoot.org/home)

The complete workshop is available at [Devoxx4kids](http://www.devoxx4kids.org/materials/workshops/greenfoot/)

Have fun :)